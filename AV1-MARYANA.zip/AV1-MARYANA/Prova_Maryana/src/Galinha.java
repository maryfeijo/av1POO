
public class Galinha extends Ave{
	public void locomover() {
		// TODO Auto-generated method stub
		System.out.println("Andando.");
	}
}
