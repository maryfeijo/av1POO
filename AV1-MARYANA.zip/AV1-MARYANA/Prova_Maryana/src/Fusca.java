
public class Fusca extends Carro{
	
	public void mostrarMarca(String marca) 
		{
			this.marca = marca;
		}
		
}
