
public class Carro extends Veiculo {

	public Carro() {
		// TODO Auto-generated constructor stub
	}
	public void setVelocidade(int velocidade) {
		this.velocidade = 150;
	}
	public void setPotencia(int potencia) {
		this.potencia = 130;
	}

	public void mostrarMarca(String marca) 
	{
		this.marca = marca;
	}
	
}
