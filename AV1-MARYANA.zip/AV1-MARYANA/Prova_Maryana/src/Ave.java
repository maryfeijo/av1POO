
public class Ave {
	public void locomover() {
		// TODO Auto-generated method stub
		System.out.println("Pulando.");
	}
	
}
