
public class TestFusca {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Fusca fusca = new Fusca();
		fusca.getMarca();
		fusca.getPotencia();
		fusca.getVelocidade();
	}

}
