
public class Mamifero {

	public void locomover() {
		// TODO Auto-generated method stub
		System.out.println("Correndo!!");
	}
}
